﻿Imports System.Data.OleDb

Public Class Login
    Dim Provider As String
    Dim dataFile As String
    Dim connString As String
    Dim myConnection As OleDbConnection = New OleDbConnection

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
        dataFile = "FLCDatabaseFinal.accdb"
        connString = Provider & dataFile
        myConnection.ConnectionString = connString

        Dim cmd As OleDbCommand = New OleDbCommand("SELECT * FROM [tblLogin] WHERE [username] = '" & txtUsername.Text & "' AND [password]='" & txtPassword.Text & "'", myConnection)
        myConnection.Open()
        Dim dr As OleDbDataReader = cmd.ExecuteReader
        Dim userFound As Boolean = False
        'the following variables will hold the user first and last name if found.'
        Dim FirstName As String = ""
        Dim SecondName As String = ""

        'if found'
        While dr.Read
            userFound = True
            FirstName = dr("FirstName").ToString
            SecondName = dr("SecondName").ToString
            txtUsername.Clear()
            txtPassword.Clear()
        End While

        'Checking the result'
        If userFound = True Then
            Main.Show()
            'Home.Label4.Text = "Welcome " & FirstName & " " & SecondName
        Else
            MsgBox("Sorry,username and password not found", MsgBoxStyle.OkOnly, "Invalid Login")
            txtUsername.Clear()
            txtPassword.Clear()
        End If
        myConnection.Close()
    End Sub

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
