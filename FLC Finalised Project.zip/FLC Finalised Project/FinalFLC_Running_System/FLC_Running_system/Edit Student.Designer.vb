﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Edit_Student
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnProgramDetails = New System.Windows.Forms.Button()
        Me.FLCDatabaseFinalDataSet = New FreshStartSystem.FLCDatabaseFinalDataSet()
        Me.grpPersonalDetails = New System.Windows.Forms.GroupBox()
        Me.cmbPayCode = New System.Windows.Forms.ComboBox()
        Me.TblStudentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.dtpDateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.cmbNationality = New System.Windows.Forms.ComboBox()
        Me.txtCellPhone = New System.Windows.Forms.TextBox()
        Me.txtFax = New System.Windows.Forms.TextBox()
        Me.txtTelephone = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtFullname = New System.Windows.Forms.TextBox()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.txtFname = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.TblStudentTableAdapter = New FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.tblStudentTableAdapter()
        Me.StudentStatusTableAdapter1 = New FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.StudentStatusTableAdapter()
        Me.TblPaymentTableAdapter1 = New FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.tblPaymentTableAdapter()
        Me.TblPaymentBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentStatusBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupBox1.SuspendLayout()
        CType(Me.FLCDatabaseFinalDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpPersonalDetails.SuspendLayout()
        CType(Me.TblStudentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPaymentBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentStatusBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.btnCancel)
        Me.GroupBox1.Controls.Add(Me.btnDelete)
        Me.GroupBox1.Controls.Add(Me.btnSave)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 422)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(830, 82)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        '
        'Button4
        '
        Me.Button4.Image = Global.FreshStartSystem.My.Resources.Resources.nex
        Me.Button4.Location = New System.Drawing.Point(343, 25)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(46, 41)
        Me.Button4.TabIndex = 7
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Image = Global.FreshStartSystem.My.Resources.Resources.last
        Me.Button3.Location = New System.Drawing.Point(433, 25)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(46, 41)
        Me.Button3.TabIndex = 6
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Image = Global.FreshStartSystem.My.Resources.Resources.Previous
        Me.Button2.Location = New System.Drawing.Point(260, 25)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(46, 41)
        Me.Button2.TabIndex = 5
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Image = Global.FreshStartSystem.My.Resources.Resources.first
        Me.Button1.Location = New System.Drawing.Point(180, 25)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(46, 40)
        Me.Button1.TabIndex = 4
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Image = Global.FreshStartSystem.My.Resources.Resources._exit
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(658, 25)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(97, 39)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Exit"
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Image = Global.FreshStartSystem.My.Resources.Resources.Dele
        Me.btnDelete.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnDelete.Location = New System.Drawing.Point(519, 25)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(97, 40)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Image = Global.FreshStartSystem.My.Resources.Resources.Save
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.Location = New System.Drawing.Point(47, 24)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(97, 41)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnProgramDetails
        '
        Me.btnProgramDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProgramDetails.ForeColor = System.Drawing.Color.Black
        Me.btnProgramDetails.Location = New System.Drawing.Point(355, 364)
        Me.btnProgramDetails.Name = "btnProgramDetails"
        Me.btnProgramDetails.Size = New System.Drawing.Size(96, 40)
        Me.btnProgramDetails.TabIndex = 7
        Me.btnProgramDetails.Text = "Next"
        Me.btnProgramDetails.UseVisualStyleBackColor = True
        '
        'FLCDatabaseFinalDataSet
        '
        Me.FLCDatabaseFinalDataSet.DataSetName = "FLCDatabaseFinalDataSet"
        Me.FLCDatabaseFinalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'grpPersonalDetails
        '
        Me.grpPersonalDetails.Controls.Add(Me.cmbPayCode)
        Me.grpPersonalDetails.Controls.Add(Me.Label16)
        Me.grpPersonalDetails.Controls.Add(Me.txtEmail)
        Me.grpPersonalDetails.Controls.Add(Me.dtpDateOfBirth)
        Me.grpPersonalDetails.Controls.Add(Me.ComboBox3)
        Me.grpPersonalDetails.Controls.Add(Me.ComboBox2)
        Me.grpPersonalDetails.Controls.Add(Me.cmbNationality)
        Me.grpPersonalDetails.Controls.Add(Me.txtCellPhone)
        Me.grpPersonalDetails.Controls.Add(Me.txtFax)
        Me.grpPersonalDetails.Controls.Add(Me.txtTelephone)
        Me.grpPersonalDetails.Controls.Add(Me.txtAddress)
        Me.grpPersonalDetails.Controls.Add(Me.txtFullname)
        Me.grpPersonalDetails.Controls.Add(Me.txtSurname)
        Me.grpPersonalDetails.Controls.Add(Me.txtFname)
        Me.grpPersonalDetails.Controls.Add(Me.txtID)
        Me.grpPersonalDetails.Controls.Add(Me.Label13)
        Me.grpPersonalDetails.Controls.Add(Me.Label12)
        Me.grpPersonalDetails.Controls.Add(Me.Label11)
        Me.grpPersonalDetails.Controls.Add(Me.Label10)
        Me.grpPersonalDetails.Controls.Add(Me.Label9)
        Me.grpPersonalDetails.Controls.Add(Me.Label8)
        Me.grpPersonalDetails.Controls.Add(Me.Label7)
        Me.grpPersonalDetails.Controls.Add(Me.Label6)
        Me.grpPersonalDetails.Controls.Add(Me.Label5)
        Me.grpPersonalDetails.Controls.Add(Me.Label4)
        Me.grpPersonalDetails.Controls.Add(Me.Label3)
        Me.grpPersonalDetails.Controls.Add(Me.Label2)
        Me.grpPersonalDetails.Controls.Add(Me.Label1)
        Me.grpPersonalDetails.Controls.Add(Me.lblID)
        Me.grpPersonalDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPersonalDetails.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grpPersonalDetails.Location = New System.Drawing.Point(12, 23)
        Me.grpPersonalDetails.Name = "grpPersonalDetails"
        Me.grpPersonalDetails.Size = New System.Drawing.Size(830, 309)
        Me.grpPersonalDetails.TabIndex = 3
        Me.grpPersonalDetails.TabStop = False
        Me.grpPersonalDetails.Text = "Personl Details"
        '
        'cmbPayCode
        '
        Me.cmbPayCode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "StdPaymentCode", True))
        Me.cmbPayCode.FormattingEnabled = True
        Me.cmbPayCode.Items.AddRange(New Object() {"PD ", "NP", ""})
        Me.cmbPayCode.Location = New System.Drawing.Point(404, 244)
        Me.cmbPayCode.Name = "cmbPayCode"
        Me.cmbPayCode.Size = New System.Drawing.Size(121, 21)
        Me.cmbPayCode.TabIndex = 27
        '
        'TblStudentBindingSource
        '
        Me.TblStudentBindingSource.DataMember = "tblStudent"
        Me.TblStudentBindingSource.DataSource = Me.FLCDatabaseFinalDataSet
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.Yellow
        Me.Label16.Location = New System.Drawing.Point(380, 275)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(159, 13)
        Me.Label16.TabIndex = 26
        Me.Label16.Text = "(IDPaymentCode e.g. 5PD)"
        '
        'txtEmail
        '
        Me.txtEmail.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Email", True))
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.ForeColor = System.Drawing.Color.Navy
        Me.txtEmail.Location = New System.Drawing.Point(118, 245)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(166, 20)
        Me.txtEmail.TabIndex = 24
        '
        'dtpDateOfBirth
        '
        Me.dtpDateOfBirth.CalendarForeColor = System.Drawing.Color.Navy
        Me.dtpDateOfBirth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "DateofBirth", True))
        Me.dtpDateOfBirth.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDateOfBirth.Location = New System.Drawing.Point(76, 147)
        Me.dtpDateOfBirth.Name = "dtpDateOfBirth"
        Me.dtpDateOfBirth.Size = New System.Drawing.Size(208, 20)
        Me.dtpDateOfBirth.TabIndex = 23
        '
        'ComboBox3
        '
        Me.ComboBox3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "MaritalStatus", True))
        Me.ComboBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox3.ForeColor = System.Drawing.Color.Navy
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"Single", "Married", "Divorced"})
        Me.ComboBox3.Location = New System.Drawing.Point(622, 98)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(176, 21)
        Me.ComboBox3.TabIndex = 22
        '
        'ComboBox2
        '
        Me.ComboBox2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Gender", True))
        Me.ComboBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox2.ForeColor = System.Drawing.Color.Navy
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"M", "F"})
        Me.ComboBox2.Location = New System.Drawing.Point(370, 98)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(155, 21)
        Me.ComboBox2.TabIndex = 21
        '
        'cmbNationality
        '
        Me.cmbNationality.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Nationality", True))
        Me.cmbNationality.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbNationality.ForeColor = System.Drawing.Color.Navy
        Me.cmbNationality.FormattingEnabled = True
        Me.cmbNationality.Items.AddRange(New Object() {"PNG", "FIGI", "SOLOMON Is", "OTHERS (Specify)"})
        Me.cmbNationality.Location = New System.Drawing.Point(115, 98)
        Me.cmbNationality.Name = "cmbNationality"
        Me.cmbNationality.Size = New System.Drawing.Size(166, 21)
        Me.cmbNationality.TabIndex = 20
        '
        'txtCellPhone
        '
        Me.txtCellPhone.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Cell phone", True))
        Me.txtCellPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCellPhone.ForeColor = System.Drawing.Color.Navy
        Me.txtCellPhone.Location = New System.Drawing.Point(622, 199)
        Me.txtCellPhone.Name = "txtCellPhone"
        Me.txtCellPhone.Size = New System.Drawing.Size(176, 20)
        Me.txtCellPhone.TabIndex = 19
        '
        'txtFax
        '
        Me.txtFax.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Fax", True))
        Me.txtFax.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFax.ForeColor = System.Drawing.Color.Navy
        Me.txtFax.Location = New System.Drawing.Point(370, 199)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(155, 20)
        Me.txtFax.TabIndex = 18
        '
        'txtTelephone
        '
        Me.txtTelephone.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Telephone", True))
        Me.txtTelephone.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTelephone.ForeColor = System.Drawing.Color.Navy
        Me.txtTelephone.Location = New System.Drawing.Point(118, 199)
        Me.txtTelephone.Name = "txtTelephone"
        Me.txtTelephone.Size = New System.Drawing.Size(166, 20)
        Me.txtTelephone.TabIndex = 17
        '
        'txtAddress
        '
        Me.txtAddress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Address", True))
        Me.txtAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress.ForeColor = System.Drawing.Color.Navy
        Me.txtAddress.Location = New System.Drawing.Point(370, 147)
        Me.txtAddress.Multiline = True
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(155, 46)
        Me.txtAddress.TabIndex = 16
        '
        'txtFullname
        '
        Me.txtFullname.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "FullName", True))
        Me.txtFullname.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFullname.ForeColor = System.Drawing.Color.Navy
        Me.txtFullname.Location = New System.Drawing.Point(622, 59)
        Me.txtFullname.Name = "txtFullname"
        Me.txtFullname.Size = New System.Drawing.Size(176, 20)
        Me.txtFullname.TabIndex = 15
        '
        'txtSurname
        '
        Me.txtSurname.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Surname", True))
        Me.txtSurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSurname.ForeColor = System.Drawing.Color.Navy
        Me.txtSurname.Location = New System.Drawing.Point(370, 59)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(155, 20)
        Me.txtSurname.TabIndex = 1
        '
        'txtFname
        '
        Me.txtFname.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "FirstName", True))
        Me.txtFname.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFname.ForeColor = System.Drawing.Color.Navy
        Me.txtFname.Location = New System.Drawing.Point(115, 59)
        Me.txtFname.Name = "txtFname"
        Me.txtFname.Size = New System.Drawing.Size(166, 20)
        Me.txtFname.TabIndex = 14
        '
        'txtID
        '
        Me.txtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "StudentID", True))
        Me.txtID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtID.ForeColor = System.Drawing.Color.Navy
        Me.txtID.Location = New System.Drawing.Point(115, 26)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 20)
        Me.txtID.TabIndex = 1
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.Yellow
        Me.Label13.Location = New System.Drawing.Point(294, 252)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(92, 13)
        Me.Label13.TabIndex = 13
        Me.Label13.Text = "Payment Code:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.Yellow
        Me.Label12.Location = New System.Drawing.Point(18, 252)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(41, 13)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Email:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.Yellow
        Me.Label11.Location = New System.Drawing.Point(544, 206)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 13)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Cell Phone:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.Yellow
        Me.Label10.Location = New System.Drawing.Point(323, 202)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Fax:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Yellow
        Me.Label9.Location = New System.Drawing.Point(10, 206)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(71, 13)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Telephone:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Yellow
        Me.Label8.Location = New System.Drawing.Point(308, 154)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 13)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Address:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Yellow
        Me.Label7.Location = New System.Drawing.Point(21, 147)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 26)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Date of" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Birth:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Yellow
        Me.Label6.Location = New System.Drawing.Point(531, 95)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(85, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Marital Status"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Yellow
        Me.Label5.Location = New System.Drawing.Point(312, 98)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Gender:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Yellow
        Me.Label4.Location = New System.Drawing.Point(18, 101)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Nationality:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Yellow
        Me.Label3.Location = New System.Drawing.Point(544, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Full Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Yellow
        Me.Label2.Location = New System.Drawing.Point(304, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Surname:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Yellow
        Me.Label1.Location = New System.Drawing.Point(18, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "First Name:"
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.ForeColor = System.Drawing.Color.Yellow
        Me.lblID.Location = New System.Drawing.Point(18, 33)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(72, 13)
        Me.lblID.TabIndex = 0
        Me.lblID.Text = "Student ID:"
        '
        'TblStudentTableAdapter
        '
        Me.TblStudentTableAdapter.ClearBeforeFill = True
        '
        'StudentStatusTableAdapter1
        '
        Me.StudentStatusTableAdapter1.ClearBeforeFill = True
        '
        'TblPaymentTableAdapter1
        '
        Me.TblPaymentTableAdapter1.ClearBeforeFill = True
        '
        'Edit_Student
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(854, 538)
        Me.Controls.Add(Me.btnProgramDetails)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grpPersonalDetails)
        Me.MaximizeBox = False
        Me.Name = "Edit_Student"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Edit_Student"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.FLCDatabaseFinalDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpPersonalDetails.ResumeLayout(False)
        Me.grpPersonalDetails.PerformLayout()
        CType(Me.TblStudentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPaymentBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentStatusBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents grpPersonalDetails As System.Windows.Forms.GroupBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents dtpDateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbNationality As System.Windows.Forms.ComboBox
    Friend WithEvents txtCellPhone As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtTelephone As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtFullname As System.Windows.Forms.TextBox
    Friend WithEvents txtSurname As System.Windows.Forms.TextBox
    Friend WithEvents txtFname As System.Windows.Forms.TextBox
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents FLCDatabaseFinalDataSet As FreshStartSystem.FLCDatabaseFinalDataSet
    Friend WithEvents TblStudentBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblStudentTableAdapter As FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.tblStudentTableAdapter
    Friend WithEvents btnProgramDetails As System.Windows.Forms.Button
    Friend WithEvents cmbPayCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents StudentStatusTableAdapter1 As FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.StudentStatusTableAdapter
    Friend WithEvents TblPaymentTableAdapter1 As FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.tblPaymentTableAdapter
    Friend WithEvents TblPaymentBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents StudentStatusBindingSource1 As System.Windows.Forms.BindingSource
End Class
