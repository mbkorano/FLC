﻿Public Class View_Student

    Private Sub View_Student_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.StudentStatus' table. You can move, or remove it, as needed.
        Me.StudentStatusTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.StudentStatus)
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.tblStudent' table. You can move, or remove it, as needed.
        Me.TblStudentTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.tblStudent)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
        Main.Show()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        TblStudentBindingSource.MoveFirst()
        StudentStatusBindingSource.MoveFirst()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TblStudentBindingSource.MovePrevious()
        StudentStatusBindingSource.MovePrevious()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        TblStudentBindingSource.MoveNext()
        StudentStatusBindingSource.MoveNext()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        TblStudentBindingSource.MoveLast()
        StudentStatusBindingSource.MoveLast()
    End Sub
    Private Sub btnSearchFname_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchFname.Click
        Try
            Me.TblStudentTableAdapter.FillByName(Me.FLCDatabaseFinalDataSet.tblStudent, txtSearch.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub
    Private Sub FillByNameToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Try
        '    Me.TblStudentTableAdapter.FillByName(Me.FLCDatabaseFinalDataSet.tblStudent, FirstNameToolStripTextBox.Text)
        'Catch ex As System.Exception
        '    System.Windows.Forms.MessageBox.Show(ex.Message)
        'End Try

    End Sub

    Private Sub FillByNameToolStripButton_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FillByNameToolStripButton.Click
        'Try
        '    Me.TblStudentTableAdapter.FillByName(Me.FLCDatabaseFinalDataSet.tblStudent, FirstNameToolStripTextBox.Text)
        'Catch ex As System.Exception
        '    System.Windows.Forms.MessageBox.Show(ex.Message)
        'End Try

    End Sub

    Private Sub FirstNameToolStripTextBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FirstNameToolStripTextBox.Click

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TblStudentBindingSource.EndEdit()

        Dim deletedStudents As FLCDatabaseFinalDataSet.tblStudentDataTable = CType(
            FLCDatabaseFinalDataSet.tblStudent.GetChanges(Data.DataRowState.Added), FLCDatabaseFinalDataSet.tblStudentDataTable)

        Dim newStudents As FLCDatabaseFinalDataSet.tblStudentDataTable = CType(
            FLCDatabaseFinalDataSet.tblStudent.GetChanges(Data.DataRowState.Added), FLCDatabaseFinalDataSet.tblStudentDataTable)

        Dim editStudents As FLCDatabaseFinalDataSet.tblStudentDataTable = CType(
            FLCDatabaseFinalDataSet.tblStudent.GetChanges(Data.DataRowState.Modified), FLCDatabaseFinalDataSet.tblStudentDataTable)

        Try
            'Remove all deleted students from the student table
            If Not deletedStudents Is Nothing Then
                TblStudentTableAdapter.Update(deletedStudents)
            End If


            'Update the student status table
            TblStudentTableAdapter.Update(FLCDatabaseFinalDataSet.tblStudent)

            'Add new students to the student form

            If Not newStudents Is Nothing Then
                TblStudentTableAdapter.Update(newStudents)
            End If

            If Not editStudents Is Nothing Then
                TblStudentTableAdapter.Update(editStudents)
            End If

            FLCDatabaseFinalDataSet.AcceptChanges()


        Catch ex As Exception
            MsgBox("Update failed", MsgBoxStyle.Information, "Update Progress")

        Finally
            If Not deletedStudents Is Nothing Then
                deletedStudents.Dispose()
            End If

            If Not newStudents Is Nothing Then
                newStudents.Dispose()
            End If

            If Not editStudents Is Nothing Then
                editStudents.Dispose()
            End If

        End Try

    End Sub
End Class