﻿Public Class ProTypeDesNew

    Private Sub ProTypeDesNew_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.Program_Category' table. You can move, or remove it, as needed.
        Me.Program_CategoryTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.Program_Category)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        frmNewStudent.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
        Payment.Show()
    End Sub
End Class