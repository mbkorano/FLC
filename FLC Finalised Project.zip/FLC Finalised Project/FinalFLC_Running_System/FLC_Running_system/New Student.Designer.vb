﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.grpPersonalDetails = New System.Windows.Forms.GroupBox()
        Me.txtPaymentCode = New System.Windows.Forms.TextBox()
        Me.TblStudentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FLCDatabaseFinalDataSet = New FreshStartSystem.FLCDatabaseFinalDataSet()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.dtpDateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.cmbMaritalStatus = New System.Windows.Forms.ComboBox()
        Me.cmdGender = New System.Windows.Forms.ComboBox()
        Me.cmbNationality = New System.Windows.Forms.ComboBox()
        Me.txtCellPhone = New System.Windows.Forms.TextBox()
        Me.txtFax = New System.Windows.Forms.TextBox()
        Me.txtTelephone = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtFullname = New System.Windows.Forms.TextBox()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.txtFname = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.StudentStatusBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnLast = New System.Windows.Forms.Button()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnFirst = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.TblStudentTableAdapter = New FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.tblStudentTableAdapter()
        Me.StudentStatusTableAdapter = New FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.StudentStatusTableAdapter()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.grpPersonalDetails.SuspendLayout()
        CType(Me.TblStudentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FLCDatabaseFinalDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentStatusBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpPersonalDetails
        '
        Me.grpPersonalDetails.Controls.Add(Me.txtPaymentCode)
        Me.grpPersonalDetails.Controls.Add(Me.txtEmail)
        Me.grpPersonalDetails.Controls.Add(Me.dtpDateOfBirth)
        Me.grpPersonalDetails.Controls.Add(Me.cmbMaritalStatus)
        Me.grpPersonalDetails.Controls.Add(Me.cmdGender)
        Me.grpPersonalDetails.Controls.Add(Me.cmbNationality)
        Me.grpPersonalDetails.Controls.Add(Me.txtCellPhone)
        Me.grpPersonalDetails.Controls.Add(Me.txtFax)
        Me.grpPersonalDetails.Controls.Add(Me.txtTelephone)
        Me.grpPersonalDetails.Controls.Add(Me.txtAddress)
        Me.grpPersonalDetails.Controls.Add(Me.txtFullname)
        Me.grpPersonalDetails.Controls.Add(Me.txtSurname)
        Me.grpPersonalDetails.Controls.Add(Me.txtFname)
        Me.grpPersonalDetails.Controls.Add(Me.txtID)
        Me.grpPersonalDetails.Controls.Add(Me.Label13)
        Me.grpPersonalDetails.Controls.Add(Me.Label12)
        Me.grpPersonalDetails.Controls.Add(Me.Label11)
        Me.grpPersonalDetails.Controls.Add(Me.Label10)
        Me.grpPersonalDetails.Controls.Add(Me.Label9)
        Me.grpPersonalDetails.Controls.Add(Me.Label8)
        Me.grpPersonalDetails.Controls.Add(Me.Label7)
        Me.grpPersonalDetails.Controls.Add(Me.Label6)
        Me.grpPersonalDetails.Controls.Add(Me.Label5)
        Me.grpPersonalDetails.Controls.Add(Me.Label4)
        Me.grpPersonalDetails.Controls.Add(Me.Label3)
        Me.grpPersonalDetails.Controls.Add(Me.Label2)
        Me.grpPersonalDetails.Controls.Add(Me.Label1)
        Me.grpPersonalDetails.Controls.Add(Me.lblID)
        Me.grpPersonalDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPersonalDetails.ForeColor = System.Drawing.Color.Aqua
        Me.grpPersonalDetails.Location = New System.Drawing.Point(9, 23)
        Me.grpPersonalDetails.Name = "grpPersonalDetails"
        Me.grpPersonalDetails.Size = New System.Drawing.Size(819, 314)
        Me.grpPersonalDetails.TabIndex = 0
        Me.grpPersonalDetails.TabStop = False
        Me.grpPersonalDetails.Text = "Personl Details"
        '
        'txtPaymentCode
        '
        Me.txtPaymentCode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "StdPaymentCode", True))
        Me.txtPaymentCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPaymentCode.ForeColor = System.Drawing.Color.Navy
        Me.txtPaymentCode.Location = New System.Drawing.Point(368, 262)
        Me.txtPaymentCode.Name = "txtPaymentCode"
        Me.txtPaymentCode.Size = New System.Drawing.Size(155, 20)
        Me.txtPaymentCode.TabIndex = 25
        '
        'TblStudentBindingSource
        '
        Me.TblStudentBindingSource.DataMember = "tblStudent"
        Me.TblStudentBindingSource.DataSource = Me.FLCDatabaseFinalDataSet
        '
        'FLCDatabaseFinalDataSet
        '
        Me.FLCDatabaseFinalDataSet.DataSetName = "FLCDatabaseFinalDataSet"
        Me.FLCDatabaseFinalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtEmail
        '
        Me.txtEmail.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Email", True))
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.ForeColor = System.Drawing.Color.Navy
        Me.txtEmail.Location = New System.Drawing.Point(127, 266)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(166, 20)
        Me.txtEmail.TabIndex = 24
        '
        'dtpDateOfBirth
        '
        Me.dtpDateOfBirth.CalendarForeColor = System.Drawing.Color.Navy
        Me.dtpDateOfBirth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "DateofBirth", True))
        Me.dtpDateOfBirth.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDateOfBirth.Location = New System.Drawing.Point(74, 154)
        Me.dtpDateOfBirth.Name = "dtpDateOfBirth"
        Me.dtpDateOfBirth.Size = New System.Drawing.Size(219, 20)
        Me.dtpDateOfBirth.TabIndex = 23
        '
        'cmbMaritalStatus
        '
        Me.cmbMaritalStatus.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "MaritalStatus", True))
        Me.cmbMaritalStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbMaritalStatus.ForeColor = System.Drawing.Color.Navy
        Me.cmbMaritalStatus.FormattingEnabled = True
        Me.cmbMaritalStatus.Items.AddRange(New Object() {"Single", "Married", "Divorced"})
        Me.cmbMaritalStatus.Location = New System.Drawing.Point(625, 128)
        Me.cmbMaritalStatus.Name = "cmbMaritalStatus"
        Me.cmbMaritalStatus.Size = New System.Drawing.Size(176, 21)
        Me.cmbMaritalStatus.TabIndex = 22
        '
        'cmdGender
        '
        Me.cmdGender.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Gender", True))
        Me.cmdGender.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdGender.ForeColor = System.Drawing.Color.Navy
        Me.cmdGender.FormattingEnabled = True
        Me.cmdGender.Items.AddRange(New Object() {"M", "F"})
        Me.cmdGender.Location = New System.Drawing.Point(368, 103)
        Me.cmdGender.Name = "cmdGender"
        Me.cmdGender.Size = New System.Drawing.Size(155, 21)
        Me.cmdGender.TabIndex = 21
        '
        'cmbNationality
        '
        Me.cmbNationality.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Nationality", True))
        Me.cmbNationality.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbNationality.ForeColor = System.Drawing.Color.Navy
        Me.cmbNationality.FormattingEnabled = True
        Me.cmbNationality.Items.AddRange(New Object() {"PNG", "FIGI", "SOLOMON IS", "OTHER(Specify)"})
        Me.cmbNationality.Location = New System.Drawing.Point(127, 103)
        Me.cmbNationality.Name = "cmbNationality"
        Me.cmbNationality.Size = New System.Drawing.Size(166, 21)
        Me.cmbNationality.TabIndex = 20
        '
        'txtCellPhone
        '
        Me.txtCellPhone.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Cell phone", True))
        Me.txtCellPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCellPhone.ForeColor = System.Drawing.Color.Navy
        Me.txtCellPhone.Location = New System.Drawing.Point(625, 214)
        Me.txtCellPhone.Name = "txtCellPhone"
        Me.txtCellPhone.Size = New System.Drawing.Size(176, 20)
        Me.txtCellPhone.TabIndex = 19
        '
        'txtFax
        '
        Me.txtFax.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Fax", True))
        Me.txtFax.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFax.ForeColor = System.Drawing.Color.Navy
        Me.txtFax.Location = New System.Drawing.Point(368, 214)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(155, 20)
        Me.txtFax.TabIndex = 18
        '
        'txtTelephone
        '
        Me.txtTelephone.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Telephone", True))
        Me.txtTelephone.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTelephone.ForeColor = System.Drawing.Color.Navy
        Me.txtTelephone.Location = New System.Drawing.Point(127, 210)
        Me.txtTelephone.Name = "txtTelephone"
        Me.txtTelephone.Size = New System.Drawing.Size(166, 20)
        Me.txtTelephone.TabIndex = 17
        '
        'txtAddress
        '
        Me.txtAddress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Address", True))
        Me.txtAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress.ForeColor = System.Drawing.Color.Navy
        Me.txtAddress.Location = New System.Drawing.Point(368, 137)
        Me.txtAddress.Multiline = True
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(155, 57)
        Me.txtAddress.TabIndex = 16
        '
        'txtFullname
        '
        Me.txtFullname.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "FullName", True))
        Me.txtFullname.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFullname.ForeColor = System.Drawing.Color.Navy
        Me.txtFullname.Location = New System.Drawing.Point(625, 59)
        Me.txtFullname.Name = "txtFullname"
        Me.txtFullname.Size = New System.Drawing.Size(176, 20)
        Me.txtFullname.TabIndex = 15
        '
        'txtSurname
        '
        Me.txtSurname.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "Surname", True))
        Me.txtSurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSurname.ForeColor = System.Drawing.Color.Navy
        Me.txtSurname.Location = New System.Drawing.Point(368, 59)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(155, 20)
        Me.txtSurname.TabIndex = 1
        '
        'txtFname
        '
        Me.txtFname.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "FirstName", True))
        Me.txtFname.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFname.ForeColor = System.Drawing.Color.Navy
        Me.txtFname.Location = New System.Drawing.Point(127, 63)
        Me.txtFname.Name = "txtFname"
        Me.txtFname.Size = New System.Drawing.Size(166, 20)
        Me.txtFname.TabIndex = 14
        '
        'txtID
        '
        Me.txtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStudentBindingSource, "StudentID", True))
        Me.txtID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtID.ForeColor = System.Drawing.Color.Navy
        Me.txtID.Location = New System.Drawing.Point(127, 28)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 20)
        Me.txtID.TabIndex = 1
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.Yellow
        Me.Label13.Location = New System.Drawing.Point(310, 260)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(59, 26)
        Me.Label13.TabIndex = 13
        Me.Label13.Text = "Payment " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Code:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.Yellow
        Me.Label12.Location = New System.Drawing.Point(49, 269)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(41, 13)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Email:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.Yellow
        Me.Label11.Location = New System.Drawing.Point(553, 221)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 13)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Cell Phone:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.Yellow
        Me.Label10.Location = New System.Drawing.Point(310, 217)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Fax:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Yellow
        Me.Label9.Location = New System.Drawing.Point(49, 214)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(71, 13)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Telephone:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Yellow
        Me.Label8.Location = New System.Drawing.Point(310, 160)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 13)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Address:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Yellow
        Me.Label7.Location = New System.Drawing.Point(15, 154)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(53, 26)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Date of " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Birth:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Yellow
        Me.Label6.Location = New System.Drawing.Point(536, 131)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Marital Status:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Yellow
        Me.Label5.Location = New System.Drawing.Point(310, 111)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Gender:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Yellow
        Me.Label4.Location = New System.Drawing.Point(49, 106)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Nationality:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Yellow
        Me.Label3.Location = New System.Drawing.Point(552, 63)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Full Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Yellow
        Me.Label2.Location = New System.Drawing.Point(310, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Surname:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Yellow
        Me.Label1.Location = New System.Drawing.Point(50, 70)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "First Name:"
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.ForeColor = System.Drawing.Color.Yellow
        Me.lblID.Location = New System.Drawing.Point(49, 35)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(72, 13)
        Me.lblID.TabIndex = 0
        Me.lblID.Text = "Student ID:"
        '
        'StudentStatusBindingSource
        '
        Me.StudentStatusBindingSource.DataMember = "StudentStatus"
        Me.StudentStatusBindingSource.DataSource = Me.FLCDatabaseFinalDataSet
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnNext)
        Me.GroupBox1.Controls.Add(Me.btnLast)
        Me.GroupBox1.Controls.Add(Me.btnPrevious)
        Me.GroupBox1.Controls.Add(Me.btnClear)
        Me.GroupBox1.Controls.Add(Me.btnFirst)
        Me.GroupBox1.Controls.Add(Me.btnCancel)
        Me.GroupBox1.Controls.Add(Me.btnAdd)
        Me.GroupBox1.Controls.Add(Me.btnDelete)
        Me.GroupBox1.Location = New System.Drawing.Point(210, 402)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(418, 124)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'btnNext
        '
        Me.btnNext.Image = Global.FreshStartSystem.My.Resources.Resources.nex
        Me.btnNext.Location = New System.Drawing.Point(224, 72)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(46, 46)
        Me.btnNext.TabIndex = 7
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnLast
        '
        Me.btnLast.Image = Global.FreshStartSystem.My.Resources.Resources.last
        Me.btnLast.Location = New System.Drawing.Point(224, 17)
        Me.btnLast.Name = "btnLast"
        Me.btnLast.Size = New System.Drawing.Size(46, 41)
        Me.btnLast.TabIndex = 6
        Me.btnLast.UseVisualStyleBackColor = True
        '
        'btnPrevious
        '
        Me.btnPrevious.Image = Global.FreshStartSystem.My.Resources.Resources.Previous
        Me.btnPrevious.Location = New System.Drawing.Point(155, 72)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(46, 46)
        Me.btnPrevious.TabIndex = 5
        Me.btnPrevious.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Image = Global.FreshStartSystem.My.Resources.Resources.Save
        Me.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClear.Location = New System.Drawing.Point(25, 76)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(97, 41)
        Me.btnClear.TabIndex = 0
        Me.btnClear.Text = "Clear"
        Me.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnFirst
        '
        Me.btnFirst.Image = Global.FreshStartSystem.My.Resources.Resources.first
        Me.btnFirst.Location = New System.Drawing.Point(155, 17)
        Me.btnFirst.Name = "btnFirst"
        Me.btnFirst.Size = New System.Drawing.Size(46, 41)
        Me.btnFirst.TabIndex = 4
        Me.btnFirst.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Image = Global.FreshStartSystem.My.Resources.Resources._exit
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(302, 73)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(97, 45)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Exit"
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Image = Global.FreshStartSystem.My.Resources.Resources.Add_new1
        Me.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAdd.Location = New System.Drawing.Point(25, 19)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(97, 46)
        Me.btnAdd.TabIndex = 2
        Me.btnAdd.Text = "Add"
        Me.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Image = Global.FreshStartSystem.My.Resources.Resources.Dele
        Me.btnDelete.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnDelete.Location = New System.Drawing.Point(302, 19)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(97, 46)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'TblStudentTableAdapter
        '
        Me.TblStudentTableAdapter.ClearBeforeFill = True
        '
        'StudentStatusTableAdapter
        '
        Me.StudentStatusTableAdapter.ClearBeforeFill = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(348, 360)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(119, 36)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Next"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmNewStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(854, 538)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grpPersonalDetails)
        Me.MaximizeBox = False
        Me.Name = "frmNewStudent"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "New Student"
        Me.grpPersonalDetails.ResumeLayout(False)
        Me.grpPersonalDetails.PerformLayout()
        CType(Me.TblStudentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FLCDatabaseFinalDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentStatusBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpPersonalDetails As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtPaymentCode As System.Windows.Forms.TextBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents dtpDateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmbMaritalStatus As System.Windows.Forms.ComboBox
    Friend WithEvents cmdGender As System.Windows.Forms.ComboBox
    Friend WithEvents cmbNationality As System.Windows.Forms.ComboBox
    Friend WithEvents txtCellPhone As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtTelephone As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtFullname As System.Windows.Forms.TextBox
    Friend WithEvents txtSurname As System.Windows.Forms.TextBox
    Friend WithEvents txtFname As System.Windows.Forms.TextBox
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnPrevious As System.Windows.Forms.Button
    Friend WithEvents btnFirst As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnLast As System.Windows.Forms.Button
    Friend WithEvents FLCDatabaseFinalDataSet As FreshStartSystem.FLCDatabaseFinalDataSet
    Friend WithEvents TblStudentBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblStudentTableAdapter As FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.tblStudentTableAdapter
    Friend WithEvents StudentStatusBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StudentStatusTableAdapter As FreshStartSystem.FLCDatabaseFinalDataSetTableAdapters.StudentStatusTableAdapter
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
