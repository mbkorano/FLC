﻿Public Class Home

    Private Sub Home_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.tblStaffDirectory' table. You can move, or remove it, as needed.
        Me.TblStaffDirectoryTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.tblStaffDirectory)
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.tblPrograms' table. You can move, or remove it, as needed.
        Me.TblProgramsTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.tblPrograms)
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.Program_Category' table. You can move, or remove it, as needed.
        Me.Program_CategoryTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.Program_Category)
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.StudentStatus' table. You can move, or remove it, as needed.
        Me.StudentStatusTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.StudentStatus)
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.tblStudent' table. You can move, or remove it, as needed.
        Me.TblStudentTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.tblStudent)
    End Sub

    Private Sub TabPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage1.Click

    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub TabPage2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        TblStudentBindingSource.MovePrevious()
        ProgramCategoryBindingSource.MovePrevious()
        TblProgramsBindingSource.MovePrevious()
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        TblStudentBindingSource.MoveNext()
        ProgramCategoryBindingSource.MoveNext()
        TblProgramsBindingSource.MoveNext()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TblStudentBindingSource.AddNew()
        ProgramCategoryBindingSource.AddNew()
        TblProgramsBindingSource.AddNew()
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        TblStudentBindingSource.EndEdit()
        TblStudentTableAdapter.Update(FLCDatabaseFinalDataSet.tblStudent)

    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        TblStudentBindingSource.RemoveCurrent()
        ProgramCategoryBindingSource.RemoveCurrent()
        TblProgramsBindingSource.RemoveCurrent()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TblStudentBindingSource.MovePrevious()
        StudentStatusBindingSource.MovePrevious()

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        TblStudentBindingSource.MoveNext()
        StudentStatusBindingSource.MoveNext()
    End Sub

    Private Sub Button22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button22.Click
        Try
            TblStudentBindingSource.RemoveCurrent()
            StudentStatusBindingSource.RemoveCurrent()
        Catch ex As Exception

        End Try
        

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        'Try
        '    Me.ValidateChildren()
        '    TblStudentBindingSource.EndEdit()
        '    TblStudentTableAdapter.Update(Me.FLCDatabaseFinalDataSet)
        'Catch ex As Exception

        'End Try
        TblStudentTableAdapter.Update(FLCDatabaseFinalDataSet.tblStudent)

    End Sub

    Private Sub Label3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        Me.Hide()
        Login.Show()
    End Sub

    Private Sub ComboBox7_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox7.SelectedIndexChanged

    End Sub

    Private Sub GroupBox5_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox5.Enter

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        lblTime.Text = Format(Now, "Hh:Nn:Ss AM/PM")
    End Sub
End Class