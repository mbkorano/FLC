﻿'Public Class NotImplementedException
'    Inherits SystemException

'    Dim instance As NotImplementedException
'End Class


Public Class Edit_Student

    Private Property Student_StatusBindingSource As Object

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TblStudentBindingSource.MoveFirst()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
        Main.Show()
    End Sub

    Private Sub Edit_Student_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.tblStudent' table. You can move, or remove it, as needed.
        Me.TblStudentTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.tblStudent)
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.tblPrograms' table. You can move, or remove it, as needed.

    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TblStudentBindingSource.MoveLast()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TblStudentBindingSource.MovePrevious()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        TblStudentBindingSource.MoveNext()

    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged

    End Sub
    Private Sub btnProgramDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProgramDetails.Click
        Me.Close()
        Payment.Show()
    End Sub

    Private Sub grpPrograms_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub cmbNationality_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbNationality.SelectedIndexChanged

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        'Me.Validate()
        'Me.TblStudentBindingSource.EndEdit()
        'Me.StudentStatusBindingSource1.EndEdit()

        Me.Validate()
        Me.TblStudentBindingSource.EndEdit()

        Dim deletedStudents As FLCDatabaseFinalDataSet.tblStudentDataTable = CType(
            FLCDatabaseFinalDataSet.tblStudent.GetChanges(Data.DataRowState.Added), FLCDatabaseFinalDataSet.tblStudentDataTable)




        ''For student table
        'Dim deletedStudents As FLCDatabaseFinalDataSet.tblStudentDataTable = CType(
        '    FLCDatabaseFinalDataSet.tblStudent.GetChanges(Data.DataRowState.Deleted), FLCDatabaseFinalDataSet.tblStudentDataTable)

        Dim newStudents As FLCDatabaseFinalDataSet.tblStudentDataTable = CType(
            FLCDatabaseFinalDataSet.tblStudent.GetChanges(Data.DataRowState.Added), FLCDatabaseFinalDataSet.tblStudentDataTable)

        Dim editStudents As FLCDatabaseFinalDataSet.tblStudentDataTable = CType(
            FLCDatabaseFinalDataSet.tblStudent.GetChanges(Data.DataRowState.Modified), FLCDatabaseFinalDataSet.tblStudentDataTable)

        ' ''For payment table
        ''Dim deletedPayment As FLCDatabaseFinalDataSet.tblPaymentDataTable = CType(
        ''    FLCDatabaseFinalDataSet.tblPayment.GetChanges(Data.DataRowState.Deleted), FLCDatabaseFinalDataSet.tblPaymentDataTable)

        ''Dim newPayment As FLCDatabaseFinalDataSet.tblPaymentDataTable = CType(
        ''    FLCDatabaseFinalDataSet.tblPayment.GetChanges(Data.DataRowState.Added), FLCDatabaseFinalDataSet.tblPaymentDataTable)

        ''Dim editPayment As FLCDatabaseFinalDataSet.tblPaymentDataTable = CType(
        ''    FLCDatabaseFinalDataSet.tblPayment.GetChanges(Data.DataRowState.Modified), FLCDatabaseFinalDataSet.tblPaymentDataTable)



        Try
            'Remove all deleted students from the student table
            If Not deletedStudents Is Nothing Then
                TblStudentTableAdapter.Update(deletedStudents)
            End If

            ''Remove all deleted payment from the payment table
            'If Not deletedPayment Is Nothing Then
            '    TblPaymentTableAdapter1.Update(deletedPayment)
            'End If

            'Update the student status table
            TblStudentTableAdapter.Update(FLCDatabaseFinalDataSet.tblStudent)

            'Add new students to the student form

            If Not newStudents Is Nothing Then
                TblStudentTableAdapter.Update(newStudents)
            End If

            'If Not newPayment Is Nothing Then
            '    TblPaymentTableAdapter1.Update(newPayment)
            'End If

            'Update all editted payment 

            If Not editStudents Is Nothing Then
                TblStudentTableAdapter.Update(editStudents)
            End If

            'If Not editPayment Is Nothing Then
            '    TblPaymentTableAdapter1.Update(editPayment)
            'End If

            FLCDatabaseFinalDataSet.AcceptChanges()


        Catch ex As Exception
            MsgBox("Update failed", MsgBoxStyle.Information, "Update Progress")

        Finally
            If Not deletedStudents Is Nothing Then
                deletedStudents.Dispose()
            End If

            'If Not deletedPayment Is Nothing Then
            '    deletedPayment.Dispose()
            'End If

            If Not newStudents Is Nothing Then
                newStudents.Dispose()
            End If

            'If Not newPayment Is Nothing Then
            '    newPayment.Dispose()
            'End If

            If Not editStudents Is Nothing Then
                editStudents.Dispose()
            End If

            'If Not editPayment Is Nothing Then
            '    editPayment.Dispose()
            'End If

        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        TblStudentBindingSource.RemoveCurrent()
    End Sub

End Class