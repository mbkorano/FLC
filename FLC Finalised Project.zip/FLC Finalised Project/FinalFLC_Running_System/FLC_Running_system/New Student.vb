﻿
Public Class frmNewStudent
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
        Main.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFirst.Click
        TblStudentBindingSource.MoveFirst()
        StudentStatusBindingSource.MoveFirst()
    End Sub

    Private Sub frmNewStudent_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.StudentStatus' table. You can move, or remove it, as needed.
        Me.StudentStatusTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.StudentStatus)
        'TODO: This line of code loads data into the 'FLCDatabaseFinalDataSet.tblPrograms' table. You can move, or remove it, as needed.
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLast.Click
        TblStudentBindingSource.MoveLast()
        StudentStatusBindingSource.MoveLast()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrevious.Click
        TblStudentBindingSource.MovePrevious()
        StudentStatusBindingSource.MovePrevious()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        TblStudentBindingSource.MoveNext()
        StudentStatusBindingSource.MoveNext()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        TblStudentBindingSource.RemoveCurrent()
        StudentStatusBindingSource.RemoveCurrent()
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Me.TblStudentTableAdapter.Insert(Me.txtID.Text, Me.txtFname.Text, Me.txtSurname.Text, Me.txtFullname.Text, Me.cmbNationality.Text, _
                                                    Me.cmdGender.Text, Me.cmbMaritalStatus.Text, Me.dtpDateOfBirth.DataBindings.ToString, Me.txtAddress.Text, Me.txtTelephone.Text, Me.txtFax.Text, Me.txtCellPhone.Text, _
                                                    Me.txtEmail.Text)
        Me.TblStudentTableAdapter.Fill(Me.FLCDatabaseFinalDataSet.tblStudent)
        MsgBox("Record added successfully")
        txtID.Text = ""
        txtFname.Text = ""
        txtSurname.Text = ""
        txtFullname.Text = ""
        cmbNationality.Text = ""
        cmdGender.Text = ""
        cmbMaritalStatus.Text = ""
        txtAddress.Text = ""
        txtTelephone.Text = ""
        txtFax.Text = ""
        txtCellPhone.Text = ""
        txtEmail.Text = ""
        txtPaymentCode.Text = ""

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
        Payment.Show()
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtID.Text = ""
        txtFname.Text = ""
        txtSurname.Text = ""
        txtFullname.Text = ""
        cmbNationality.Text = ""
        cmdGender.Text = ""
        cmbMaritalStatus.Text = ""
        txtAddress.Text = ""
        txtTelephone.Text = ""
        txtFax.Text = ""
        txtCellPhone.Text = ""
        txtEmail.Text = ""
        txtPaymentCode.Text = ""
    End Sub
End Class