﻿Partial Class FLCDatabaseFinalDataSet
    Partial Class tblStudentDataTable

        Private Sub tblStudentDataTable_tblStudentRowChanging(ByVal sender As System.Object, ByVal e As tblStudentRowChangeEvent) Handles Me.tblStudentRowChanging

        End Sub

    End Class

    Partial Class StudentStatusDataTable

        Private Sub StudentStatusDataTable_ColumnChanging(ByVal sender As System.Object, ByVal e As System.Data.DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.stuStatusCodeColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class

End Class
